import React, { useState } from "react";
import FormularioVenta from "../components/FormularioVenta";
import TablaProductosVenta from "../components/TablaProductosVenta";

function VentasPage() {
  const [productoActual, setProductoActual] = useState({
    id: '',
    nombre: '',
    codigo: '',
    precio: 0,
    cantidad: 1,
    descuento: 0,
  });

  const [productosAgregados, setProductosAgregados] = useState([]);
  const [dineroRecibido, setDineroRecibido] = useState(0);
  const [formaDePago, setFormaDePago] = useState("Efectivo");
  const [mensaje, setMensaje] = useState('');

  const totalVenta = productosAgregados.reduce((total, p) => {
    const subtotal = p.precio * p.cantidad;
    const descuento = subtotal * (p.descuento / 100);
    return total + (subtotal - descuento);
  }, 0);

  const cambio = dineroRecibido - totalVenta;

  const consultarProducto = async () => {
    try {
      const codigo = productoActual.codigo;
      const res = await fetch(`http://localhost:8080/productos/codigo/${codigo}`, {
        headers: {
          'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        }
      });

      if (!res.ok) throw new Error("Producto no encontrado");
      const producto = await res.json();
      setProductoActual({
        ...productoActual,
        id: producto.id,
        nombre: producto.nombre,
        precio: producto.precio,
      });
      setMensaje("✅ Producto encontrado");
    } catch (error) {
      setMensaje("❌ Producto no encontrado");
    }
  };

  const agregarProducto = () => {
    if (!productoActual.id) {
      setMensaje("⚠️ Debes buscar un producto válido");
      return;
    }
    setProductosAgregados([...productosAgregados, productoActual]);
    setProductoActual({
      id: '',
      nombre: '',
      codigo: '',
      precio: 0,
      cantidad: 1,
      descuento: 0,
    });
    setMensaje("✅ Producto agregado");
  };

  const eliminarProducto = (index) => {
    const nuevosProductos = productosAgregados.filter((_, i) => i !== index);
    setProductosAgregados(nuevosProductos);
  };

  const registrarVenta = async () => {
    try {
      const venta = {
        productos: productosAgregados,
        formaDePago,
        total: totalVenta,
        dineroRecibido,
      };

      const res = await fetch("http://localhost:8080/ventas", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          'Authorization': `Bearer ${sessionStorage.getItem('token')}`,
        },
        body: JSON.stringify(venta),
      });

      if (!res.ok) throw new Error("Error al registrar la venta");
      await res.json();
      setMensaje("✅ Venta registrada con éxito");

      setProductosAgregados([]);
      setDineroRecibido(0);
      setFormaDePago("Efectivo");
      setProductoActual({
        id: '',
        nombre: '',
        codigo: '',
        precio: 0,
        cantidad: 1,
        descuento: 0,
      });
    } catch (error) {
      console.error("Error:", error);
      setMensaje("❌ Error al registrar la venta");
    }
  };

  return React.createElement("div", { className: "container mt-4" },
    React.createElement("h1", null, "Registrar Venta"),
    React.createElement(FormularioVenta, {
      producto: productoActual,
      setProducto: setProductoActual,
      agregarProducto,
      dineroRecibido,
      setDineroRecibido,
      cambio,
      totalVenta,
      consultarProducto,
      mensaje
    }),
    React.createElement(TablaProductosVenta, {
      productos: productosAgregados,
      eliminarProducto,
      formaDePago,
      setFormaDePago,
      totalVenta,
      registrarVenta
    })
  );
}

export default VentasPage;