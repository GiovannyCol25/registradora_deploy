function ProveedoresPage() {
    return <h1>Página de Proveedores</h1>;
  }
  export default ProveedoresPage;